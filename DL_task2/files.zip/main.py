import argparse
import sys
from src.train import train_model
from src.predict import predict_from_csv
from src.config import Config

def main():
    parser = argparse.ArgumentParser(description='Ventilator Parameter Prediction')
    parser.add_argument('mode', choices=['train', 'predict'], help='Mode: train or predict')
    parser.add_argument('--data', required=True, help='Path to CSV data file')
    parser.add_argument('--model', default=Config.MODEL_PATH, help='Path to model file')
    parser.add_argument('--output', default=Config.PREDICTIONS_PATH, help='Path to output predictions file')
    
    args = parser.parse_args()
    
    if args.mode == 'train':
        print("Starting training...")
        train_model(args.data)
        print("Training completed!")
        
    elif args.mode == 'predict':
        print("Starting prediction...")
        predict_from_csv(args.data, args.model, args.output)
        print("Prediction completed!")

if __name__ == '__main__':
    main()