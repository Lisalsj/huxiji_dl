import torch
import pandas as pd
import numpy as np
import json
from src.model import create_model
from src.data_loader import DataProcessor
from src.config import Config
from src.utils import format_prediction_result

class Predictor:
    def __init__(self, model_path):
        self.config = Config()
        self.device = self.config.DEVICE
        self.data_processor = DataProcessor()
        
        # 加载模型
        self.model = create_model().to(self.device)
        self.load_model(model_path)
        
    def load_model(self, model_path):
        """加载训练好的模型"""
        try:
            checkpoint = torch.load(model_path, map_location=self.device)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            self.model.eval()
            print(f"Model loaded from {model_path}")
        except Exception as e:
            raise Exception(f"Error loading model: {e}")
    
    def preprocess_single_sample(self, df):
        """预处理单个样本"""
        # 处理VENTMODE映射
        df['SET_VENTMODE'] = df['SET_VENTMODE'].astype(str).map(
            self.config.VENTMODE_MAPPING
        ).fillna(df['SET_VENTMODE'])
        
        # 提取输入特征
        input_features = []
        for col in self.config.INPUT_FEATURES:
            if col in df.columns:
                input_features.append(col)
        
        X = df[input_features].values
        
        # 使用训练时的scaler进行标准化（这里需要保存scaler或使用简单的标准化）
        # 为简化，这里使用简单的归一化
        X_normalized = self.simple_normalize(X)
        
        return X_normalized
    
    def simple_normalize(self, X):
        """简单的特征归一化"""
        # 这里使用一个简化的归一化方法
        # 在实际应用中，应该保存训练时的scaler参数
        X_normalized = (X - np.mean(X, axis=0, keepdims=True)) / (np.std(X, axis=0, keepdims=True) + 1e-8)
        return X_normalized
    
    def predict(self, data_path, output_path=None):
        """对CSV文件进行预测"""
        # 加载数据
        df = pd.read_csv(data_path)
        
        # 预处理
        X = self.preprocess_single_sample(df)
        
        # 转换为tensor
        X_tensor = torch.FloatTensor(X).to(self.device)
        
        predictions = []
        
        with torch.no_grad():
            for i in range(len(X_tensor)):
                # 单样本预测
                sample = X_tensor[i:i+1]
                numerical_outputs, mode_output = self.model(sample)
                
                # 解析预测结果
                numerical_preds = []
                for output in numerical_outputs:
                    pred = torch.argmax(output, dim=1).item()
                    numerical_preds.append(pred)
                
                mode_pred = torch.argmax(mode_output, dim=1).item()
                
                # 格式化结果
                prediction_text = format_prediction_result(numerical_preds, mode_pred, self.config)
                
                prediction = {
                    "id": i,
                    "task1_output": prediction_text
                }
                predictions.append(prediction)
        
        # 保存结果
        if output_path is None:
            output_path = self.config.PREDICTION_OUTPUT_PATH
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(predictions, f, indent=2, ensure_ascii=False)
        
        print(f"Predictions saved to {output_path}")
        return predictions
    
    def predict_single(self, sample_data):
        """预测单个样本"""
        # 将字典转换为DataFrame
        df = pd.DataFrame([sample_data])
        
        # 预处理
        X = self.preprocess_single_sample(df)
        X_tensor = torch.FloatTensor(X).to(self.device)
        
        with torch.no_grad():
            numerical_outputs, mode_output = self.model(X_tensor)
            
            # 解析预测结果
            numerical_preds = []
            for output in numerical_outputs:
                pred = torch.argmax(output, dim=1).item()
                numerical_preds.append(pred)
            
            mode_pred = torch.argmax(mode_output, dim=1).item()
            
            # 格式化结果
            prediction_text = format_prediction_result(numerical_preds, mode_pred, self.config)
            
            return prediction_text

def predict_from_csv(model_path, data_path, output_path=None):
    """从CSV文件预测的主函数"""
    predictor = Predictor(model_path)
    predictions = predictor.predict(data_path, output_path)
    return predictions